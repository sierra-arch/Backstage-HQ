import React, { useEffect, useMemo, useState } from "react";

/**
 * Backstage OS — Calming Dashboard + Progressive Onboarding (v1.4)
 *
 * Key behaviors:
 * - Default skin = Backstage (green) baseline.
 * - One-time onboarding. Re-take only via Settings.
 * - Settings opens by clicking the name/logo area in header.
 * - Business Health: icon-only overview + expandable detail drawer.
 * - Onboarding expanded with “founder heart” prompts (inspired by Week One workbook themes).
 * - AI-assisted Skin (optional): when AI is available, allow exact color inputs + logo mock generation if no upload.
 * - Confetti burst on “Your space is ready.” (kept!)
 *
 * Notes:
 * - This prototype is local-only: it stores state in localStorage.
 * - All “AI” actions are stubbed as demos (no network calls).
 */

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function cx(...c: Array<string | false | undefined | null>) {
  return c.filter(Boolean).join(" ");
}

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function hexToRgb(hex: string) {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((x) => x + x).join("") : h;
  const n = parseInt(full, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function mixHex(a: string, b: string, t: number) {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  const m = (x: number, y: number) => Math.round(x + (y - x) * t);
  const r = m(A.r, B.r);
  const g = m(A.g, B.g);
  const bl = m(A.b, B.b);
  const toHex = (v: number) => v.toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(bl)}`;
}

function safeHex(input: string) {
  const s = (input || "").trim();
  if (!s) return "";
  const v = s.startsWith("#") ? s : `#${s}`;
  return /^#[0-9a-fA-F]{6}$/.test(v) || /^#[0-9a-fA-F]{3}$/.test(v) ? v : "";
}

// ─────────────────────────────────────────────────────────────────────────────
// Persistence
// ─────────────────────────────────────────────────────────────────────────────

const LS_KEY = "backstage_os_v1";

type Persisted = {
  onboardingCompleted: boolean;
  stage: number;
  answers: Answers;
  aiAvailable: boolean;
};

function loadPersisted(): Persisted | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function savePersisted(p: Persisted) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(p));
  } catch {
    // ignore
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Skin tokens (Backstage default + progressive custom layer)
// ─────────────────────────────────────────────────────────────────────────────

const BACKSTAGE_DEFAULT = {
  name: "Backstage Default",
  bg: "#F6F7F6",
  surface: "#FFFFFF",
  border: "#E6E8EA",
  text: "#0B1220",
  subtext: "#475569",
  chip: "#F0F3F5",
  accent: "#0E8A67", // Backstage green
  accentText: "#052E23",
  primaryBg: "#0B1220",
  primaryText: "#FFFFFF",
};

const ACCENT_PRESETS = {
  backstageGreen: "#0E8A67",
  sage: "#10B981",
  ocean: "#3B82F6",
  plum: "#8B5CF6",
  sand: "#F59E0B",
  rose: "#F43F5E",
  slate: "#64748B",
};

function computeAccentFromDirection(direction: string) {
  switch (direction) {
    case "soft_accents":
      return { accent: ACCENT_PRESETS.backstageGreen, accentText: "#052E23" };
    case "bold_accents":
      return { accent: ACCENT_PRESETS.ocean, accentText: "#061A3A" };
    case "dark_neutral":
      return { accent: ACCENT_PRESETS.plum, accentText: "#1B1030" };
    case "light_neutral":
    default:
      return { accent: ACCENT_PRESETS.backstageGreen, accentText: "#052E23" };
  }
}

type Answers = {
  // basics
  businessName: string;
  industry: string;
  audienceLabel: string;

  // feel + brand
  tone: string[];
  colorDirection: string;
  logoMode: "uploaded" | "wordmark";

  // founder-heart (Week One themes)
  founderTitle: string;
  whoServe: string;
  whatDo: string;
  soTheyCan: string;

  whyThisMatters: string; // "why do you care?"
  clientStruggle: string; // what are they up against?
  clientRelief: string;   // what changes for them?

  craft: string; // what do you do best?
  aboutYou: string; // 3-5 sentences

  charitableGiving: string; // social responsibility
  nonNegotiables: string; // boundaries + ethics

  sixMonthSchedule: string; // rhythms
  oneYearHours: string;     // hours/week
  visionStatement: string;  // future goals statement

  // skin (optional)
  exactPrimary: string;
  exactSecondary: string;
  exactBg: string;

  // optional style descriptors (for AI skin/logo mock)
  styleWords: string; // 3-6 words
};

function buildSkin(answers: Answers, stageIndex: number, aiAvailable: boolean) {
  const progress = clamp(stageIndex / 7, 0, 1);
  const base = BACKSTAGE_DEFAULT;

  const p = safeHex(answers.exactPrimary);
  const s = safeHex(answers.exactSecondary);
  const b = safeHex(answers.exactBg);

  const directionAccent = computeAccentFromDirection(answers.colorDirection);
  const targetAccent = aiAvailable && p ? p : directionAccent.accent;

  const bg = mixHex(base.bg, b || base.bg, progress * (b ? 0.75 : 0.25));
  const surface = base.surface;
  const border = mixHex(base.border, "#D7DEE8", 0.25);

  const accent = mixHex(base.accent, targetAccent, clamp(progress * 1.0, 0, 1));
  const chip = mixHex(base.chip, s || base.chip, progress * (s ? 0.55 : 0.15));

  const motion = answers.tone?.includes("calm") ? "slow" : "gentle";

  return {
    name: answers.businessName?.trim() ? `${answers.businessName.trim()} Skin` : "Backstage Skin",
    bg,
    surface,
    border,
    text: base.text,
    subtext: base.subtext,
    chip,
    accent,
    accentText: directionAccent.accentText,
    primaryBg: base.primaryBg,
    primaryText: base.primaryText,
    motion,
    logoMode: answers.logoMode || "wordmark",
  };
}

function useThemeStyle(theme: any) {
  return {
    background: theme.bg,
    color: theme.text,
    "--bs-surface": theme.surface,
    "--bs-border": theme.border,
    "--bs-text": theme.text,
    "--bs-subtext": theme.subtext,
    "--bs-chip": theme.chip,
    "--bs-accent": theme.accent,
    "--bs-accentText": theme.accentText,
    "--bs-primaryBg": theme.primaryBg,
    "--bs-primaryText": theme.primaryText,
  } as React.CSSProperties;
}

// ─────────────────────────────────────────────────────────────────────────────
// App
// ─────────────────────────────────────────────────────────────────────────────

type Mode = "onboarding" | "dashboard" | "settings";

const ONBOARDING_STAGES = [
  "orientation",
  "whoServe",
  "heart",
  "craft",
  "values",
  "vision",
  "brand",
  "logo",
  "ready",
] as const;

type StageId = (typeof ONBOARDING_STAGES)[number];

const INDUSTRIES = [
  "Service Provider",
  "Creative / Studio",
  "Coach / Consultant",
  "Wedding / Event Vendor",
  "Local Business",
  "Other",
];

const TONES = ["calm", "confident", "warm", "minimal", "premium", "approachable"];

const COLOR_DIRECTIONS = [
  { id: "light_neutral", label: "Light + neutral" },
  { id: "dark_neutral", label: "Dark + neutral" },
  { id: "soft_accents", label: "Soft color accents" },
  { id: "bold_accents", label: "Bold color accents" },
];

const HEALTH_DOMAINS = [
  { id: "delivery", icon: "ring" },
  { id: "brand", icon: "spark" },
  { id: "systems", icon: "grid" },
  { id: "marketing", icon: "wave" },
  { id: "capacity", icon: "leaf" },
] as const;

type HealthDomainId = (typeof HEALTH_DOMAINS)[number]["id"];

const VAULT_TILES = [
  { id: "delivery", title: "Delivery", subtitle: "Client experience" },
  { id: "brand", title: "Brand & Assets", subtitle: "Website + visuals" },
  { id: "systems", title: "Systems", subtitle: "SOPs + automations" },
  { id: "marketing", title: "Marketing", subtitle: "Campaigns + content" },
  { id: "capacity", title: "Capacity", subtitle: "Time + support" },
];

function defaultAnswers(): Answers {
  return {
    businessName: "",
    industry: "",
    audienceLabel: "clients",

    tone: ["calm", "confident"],
    colorDirection: "light_neutral",
    logoMode: "wordmark",

    founderTitle: "",
    whoServe: "",
    whatDo: "",
    soTheyCan: "",

    whyThisMatters: "",
    clientStruggle: "",
    clientRelief: "",

    craft: "",
    aboutYou: "",

    charitableGiving: "",
    nonNegotiables: "",

    sixMonthSchedule: "",
    oneYearHours: "",
    visionStatement: "",

    exactPrimary: "",
    exactSecondary: "",
    exactBg: "",

    styleWords: "",
  };
}

export default function App() {
  const persisted = useMemo(() => loadPersisted(), []);

  const [mode, setMode] = useState<Mode>(() => {
    if (persisted?.onboardingCompleted) return "dashboard";
    return "onboarding";
  });

  const [stage, setStage] = useState<number>(() => {
    if (persisted?.onboardingCompleted) return 0;
    return persisted?.stage ?? 0;
  });

  const [aiAvailable, setAiAvailable] = useState<boolean>(() => persisted?.aiAvailable ?? true);
  const [answers, setAnswers] = useState<Answers>(() => persisted?.answers ?? defaultAnswers());
  const [onboardingCompleted, setOnboardingCompleted] = useState<boolean>(() => persisted?.onboardingCompleted ?? false);
  const [showConfetti, setShowConfetti] = useState(false);

  const stageId: StageId = ONBOARDING_STAGES[clamp(stage, 0, ONBOARDING_STAGES.length - 1)] as StageId;

  const theme = useMemo(() => buildSkin(answers, stage, aiAvailable), [answers, stage, aiAvailable]);
  const themeStyle = useMemo(() => useThemeStyle(theme), [theme]);

  useEffect(() => {
    savePersisted({ onboardingCompleted, stage, answers, aiAvailable });
  }, [onboardingCompleted, stage, answers, aiAvailable]);

  useEffect(() => {
    if (mode === "onboarding" && stageId === "ready") {
      setShowConfetti(true);
      const t = setTimeout(() => setShowConfetti(false), 2200);
      return () => clearTimeout(t);
    }
  }, [mode, stageId]);

  const openSettings = () => setMode("settings");

  return (
    <div className="min-h-screen" style={themeStyle}>
      {showConfetti ? <ConfettiBurst /> : null}

      <div className={cx("mx-auto max-w-6xl px-4 py-6", theme.motion === "slow" ? "transition-all duration-700" : "transition-all duration-500")}>
        <Header
          mode={mode}
          onGoDashboard={() => setMode("dashboard")}
          onGoOnboarding={() => {
            // Onboarding is one-time; re-take via Settings.
            if (!onboardingCompleted) {
              setMode("onboarding");
              setStage(0);
            } else {
              setMode("settings");
            }
          }}
          theme={theme}
          answers={answers}
          onOpenSettings={openSettings}
        />

        {mode === "onboarding" ? (
          <Onboarding
            theme={theme}
            stage={stage}
            stageId={stageId}
            answers={answers}
            setAnswers={setAnswers}
            aiAvailable={aiAvailable}
            onNext={() => setStage((s) => clamp(s + 1, 0, ONBOARDING_STAGES.length - 1))}
            onBack={() => setStage((s) => clamp(s - 1, 0, ONBOARDING_STAGES.length - 1))}
            onEnter={() => {
              setOnboardingCompleted(true);
              setMode("dashboard");
              setStage(0);
            }}
          />
        ) : mode === "settings" ? (
          <Settings
            theme={theme}
            answers={answers}
            setAnswers={setAnswers}
            aiAvailable={aiAvailable}
            setAiAvailable={setAiAvailable}
            onboardingCompleted={onboardingCompleted}
            onRetake={() => {
              setOnboardingCompleted(false);
              setMode("onboarding");
              setStage(0);
            }}
            onClose={() => setMode("dashboard")}
          />
        ) : (
          <Dashboard theme={theme} answers={answers} aiAvailable={aiAvailable} />
        )}
      </div>

      <div className="pb-10 text-center text-xs" style={{ color: "var(--bs-subtext)" }}>
        Draft-first. Approval-based. You stay in control.
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Header
// ─────────────────────────────────────────────────────────────────────────────

function Header({
  mode,
  onGoDashboard,
  onGoOnboarding,
  theme,
  answers,
  onOpenSettings,
}: {
  mode: Mode;
  onGoDashboard: () => void;
  onGoOnboarding: () => void;
  theme: any;
  answers: Answers;
  onOpenSettings: () => void;
}) {
  const showName = answers.businessName?.trim();

  return (
    <div className="flex flex-wrap items-center justify-between gap-4">
      <button
        className="flex items-center gap-3 rounded-3xl p-2 text-left transition"
        style={{ background: "transparent" }}
        onClick={onOpenSettings}
        aria-label="Open settings"
        title="Settings"
      >
        <BrandMark theme={theme} businessName={answers.businessName} />
        <div>
          <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
            {showName ? showName : "Backstage"}
          </div>
          <div className="text-sm" style={{ color: "var(--bs-subtext)" }}>
            {mode === "onboarding" ? "Your space is being prepared" : "Your business, clearly held."}
          </div>
        </div>
      </button>

      <div className="flex flex-wrap items-center gap-2">
        <Button kind="ghost" theme={theme} onClick={onGoOnboarding}>
          {mode === "onboarding" ? "Onboarding" : "Setup"}
        </Button>
        <Button kind="primary" theme={theme} onClick={onGoDashboard}>
          Dashboard
        </Button>
      </div>
    </div>
  );
}

function BrandMark({ theme, businessName }: { theme: any; businessName: string }) {
  const name = businessName?.trim();
  return (
    <div className="grid h-10 w-10 place-items-center rounded-2xl border" style={{ background: "var(--bs-chip)", borderColor: "var(--bs-border)" }} aria-label="Brand mark" title={name ? name : "Backstage"}>
      <div className="h-4 w-4 rounded-full" style={{ background: "var(--bs-accent)", opacity: 0.92 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Onboarding (expanded, founder-heart)
// ─────────────────────────────────────────────────────────────────────────────

function Onboarding({
  theme,
  stage,
  stageId,
  answers,
  setAnswers,
  aiAvailable,
  onNext,
  onBack,
  onEnter,
}: {
  theme: any;
  stage: number;
  stageId: StageId;
  answers: Answers;
  setAnswers: React.Dispatch<React.SetStateAction<Answers>>;
  aiAvailable: boolean;
  onNext: () => void;
  onBack: () => void;
  onEnter: () => void;
}) {
  const isReady = stageId === "ready";

  return (
    <div className="mt-6 space-y-4">
      <div className="rounded-3xl border p-5 shadow-sm" style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)" }}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-sm font-semibold" style={{ color: "var(--bs-subtext)" }}>
              Setup • step {stage + 1} of {ONBOARDING_STAGES.length}
            </div>
            <div className="mt-2 text-2xl font-semibold" style={{ color: "var(--bs-text)" }}>
              {titleForStage(stageId)}
            </div>
            <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
              {subtitleForStage(stageId)}
            </div>
          </div>

          <div className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ background: "var(--bs-chip)", borderColor: "var(--bs-border)", color: "var(--bs-text)" }}>
            Backstage OS
          </div>
        </div>

        <div className="mt-5">
          {stageId === "orientation" ? (
            <div className="space-y-3">
              <Label>What’s the name of your business?</Label>
              <TextInput value={answers.businessName} onChange={(v) => setAnswers((p) => ({ ...p, businessName: v }))} placeholder="e.g. Willow Studio, Smith Consulting, Prose Florals" />

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Which best describes your business?</Label>
                  <Select value={answers.industry} onChange={(v) => setAnswers((p) => ({ ...p, industry: v }))} options={INDUSTRIES} placeholder="Choose one" />
                </div>
                <div className="space-y-2">
                  <Label>What do you call the people you serve?</Label>
                  <TextInput value={answers.audienceLabel} onChange={(v) => setAnswers((p) => ({ ...p, audienceLabel: v }))} placeholder="clients, couples, patients, students…" />
                </div>
              </div>
              <Hint>We’re building a calm space that fits your world.</Hint>
            </div>
          ) : null}

          {stageId === "whoServe" ? (
            <div className="space-y-3">
              <Label>Fill in the blanks (quick + imperfect is perfect)</Label>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <TextInput value={answers.founderTitle} onChange={(v) => setAnswers((p) => ({ ...p, founderTitle: v }))} placeholder="I am… (your job title)" />
                <TextInput value={answers.whoServe} onChange={(v) => setAnswers((p) => ({ ...p, whoServe: v }))} placeholder="I help… (describe your client)" />
                <TextInput value={answers.whatDo} onChange={(v) => setAnswers((p) => ({ ...p, whatDo: v }))} placeholder="do… (what you do)" />
                <TextInput value={answers.soTheyCan} onChange={(v) => setAnswers((p) => ({ ...p, soTheyCan: v }))} placeholder="so they can… (how it improves their life)" />
              </div>
              <Hint>That dream was planted in your heart for a reason.</Hint>
            </div>
          ) : null}

          {stageId === "heart" ? (
            <div className="space-y-3">
              <Label>Why does this work matter to you?</Label>
              <TextArea value={answers.whyThisMatters} onChange={(v) => setAnswers((p) => ({ ...p, whyThisMatters: v }))} placeholder="What made you care enough to start this business?" />

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>What is your client up against right now?</Label>
                  <TextArea value={answers.clientStruggle} onChange={(v) => setAnswers((p) => ({ ...p, clientStruggle: v }))} placeholder="What do they struggle with, worry about, or feel stuck in?" />
                </div>
                <div className="space-y-2">
                  <Label>What do you want them to feel on the other side?</Label>
                  <TextArea value={answers.clientRelief} onChange={(v) => setAnswers((p) => ({ ...p, clientRelief: v }))} placeholder="What changes for them after working with you?" />
                </div>
              </div>
              <Hint>We’ll use your words so drafts feel sincere — not templated.</Hint>
            </div>
          ) : null}

          {stageId === "craft" ? (
            <div className="space-y-3">
              <Label>What is your main craft / skill set?</Label>
              <TextArea value={answers.craft} onChange={(v) => setAnswers((p) => ({ ...p, craft: v }))} placeholder="What do you do best — the thing people thank you for?" />

              <Label>Write a 3–5 sentence “About You” (heartfelt + real)</Label>
              <TextArea value={answers.aboutYou} onChange={(v) => setAnswers((p) => ({ ...p, aboutYou: v }))} placeholder="A few lines about your story, your expertise, and why you care." />

              <Hint>This will quietly shape your voice across templates and drafts.</Hint>
            </div>
          ) : null}

          {stageId === "values" ? (
            <div className="space-y-3">
              <Label>Do you have plans to incorporate charitable giving and/or social responsibility?</Label>
              <TextArea value={answers.charitableGiving} onChange={(v) => setAnswers((p) => ({ ...p, charitableGiving: v }))} placeholder="If yes, what does that look like? If not, what ethics guide your work?" />

              <Label>Personal non-negotiables (boundaries + ethics)</Label>
              <TextArea value={answers.nonNegotiables} onChange={(v) => setAnswers((p) => ({ ...p, nonNegotiables: v }))} placeholder="What will you never compromise on in how you serve?" />

              <Hint>These protect your peace — and your clients.</Hint>
            </div>
          ) : null}

          {stageId === "vision" ? (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-3">
                <Label>What does your schedule look like in six months?</Label>
                <TextArea value={answers.sixMonthSchedule} onChange={(v) => setAnswers((p) => ({ ...p, sixMonthSchedule: v }))} placeholder="Daily rhythms, weekly patterns, what you want your life to feel like." />
              </div>
              <div className="space-y-3">
                <Label>In one year, how many hours a week would you like to work?</Label>
                <TextInput value={answers.oneYearHours} onChange={(v) => setAnswers((p) => ({ ...p, oneYearHours: v }))} placeholder="e.g. 10, 20, 30" />

                <Label>Write your Vision Statement (future goals for your business)</Label>
                <TextArea value={answers.visionStatement} onChange={(v) => setAnswers((p) => ({ ...p, visionStatement: v }))} placeholder="What will your business accomplish? How will it make the world better?" />
              </div>
            </div>
          ) : null}

          {stageId === "brand" ? (
            <div className="space-y-3">
              <Label>How should this feel when you log in? (Pick up to two)</Label>
              <div className="flex flex-wrap gap-2">
                {TONES.map((t) => {
                  const active = answers.tone.includes(t);
                  return (
                    <Chip
                      key={t}
                      active={active}
                      theme={theme}
                      onClick={() => {
                        setAnswers((p) => {
                          const next = new Set(p.tone);
                          if (next.has(t)) next.delete(t);
                          else {
                            if (next.size >= 2) return p;
                            next.add(t);
                          }
                          return { ...p, tone: Array.from(next) };
                        });
                      }}
                    >
                      {capitalize(t)}
                    </Chip>
                  );
                })}
              </div>

              <Label>Which visual direction feels most like your business?</Label>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {COLOR_DIRECTIONS.map((c) => (
                  <PickCard key={c.id} title={c.label} selected={answers.colorDirection === c.id} onClick={() => setAnswers((p) => ({ ...p, colorDirection: c.id }))} />
                ))}
              </div>

              {aiAvailable ? (
                <div className="mt-2 rounded-3xl border p-4" style={{ borderColor: "var(--bs-border)", background: "var(--bs-surface)" }}>
                  <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
                    Optional: exact brand colors
                  </div>
                  <div className="mt-1 text-xs" style={{ color: "var(--bs-subtext)" }}>
                    If you know them, we can match your brand precisely.
                  </div>
                  <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
                    <TextInput value={answers.exactPrimary} onChange={(v) => setAnswers((p) => ({ ...p, exactPrimary: v }))} placeholder="Primary (hex) e.g. #0E8A67" />
                    <TextInput value={answers.exactSecondary} onChange={(v) => setAnswers((p) => ({ ...p, exactSecondary: v }))} placeholder="Secondary (hex)" />
                    <TextInput value={answers.exactBg} onChange={(v) => setAnswers((p) => ({ ...p, exactBg: v }))} placeholder="Background (hex)" />
                  </div>

                  <div className="mt-3">
                    <Label>Style words (3–6)</Label>
                    <TextInput value={answers.styleWords} onChange={(v) => setAnswers((p) => ({ ...p, styleWords: v }))} placeholder="e.g. clean, grounded, premium, warm" />
                    <Hint>Used for smarter suggestions (and logo mock if you don’t upload one).</Hint>
                  </div>
                </div>
              ) : null}

              <Hint>Each step reveals who you’re becoming.</Hint>
            </div>
          ) : null}

          {stageId === "logo" ? (
            <div className="space-y-3">
              <Label>Logo</Label>
              <div className="flex flex-wrap gap-2">
                <Button kind={answers.logoMode === "uploaded" ? "primary" : "ghost"} theme={theme} onClick={() => setAnswers((p) => ({ ...p, logoMode: "uploaded" }))}>
                  Upload logo (demo)
                </Button>
                <Button kind={answers.logoMode === "wordmark" ? "primary" : "ghost"} theme={theme} onClick={() => setAnswers((p) => ({ ...p, logoMode: "wordmark" }))}>
                  Skip
                </Button>
                {aiAvailable && answers.logoMode !== "uploaded" ? (
                  <Button kind="ghost" theme={theme} onClick={() => alert("Logo mock generated (demo).")}>
                    Generate logo mock
                  </Button>
                ) : null}
              </div>
              <Hint>Clean and minimal either way.</Hint>
            </div>
          ) : null}

          {isReady ? (
            <div className="space-y-3">
              <div className="text-2xl font-semibold" style={{ color: "var(--bs-text)" }}>
                Your space is ready.
              </div>
              <div className="text-sm" style={{ color: "var(--bs-subtext)" }}>
                This is your business — clearly held.
              </div>
              <div className="pt-2">
                <Button kind="primary" theme={theme} onClick={onEnter}>
                  Enter dashboard
                </Button>
              </div>
            </div>
          ) : null}
        </div>

        {!isReady ? (
          <div className="mt-6 flex items-center justify-between gap-2">
            <Button kind="ghost" theme={theme} onClick={onBack} disabled={stage === 0}>
              Back
            </Button>
            <div className="text-xs" style={{ color: "var(--bs-subtext)" }}>
              Calm progress. No irreversible choices.
            </div>
            <Button kind="primary" theme={theme} onClick={onNext}>
              Continue
            </Button>
          </div>
        ) : null}
      </div>

      <div className="rounded-3xl border p-4" style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)" }}>
        <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
          Live preview
        </div>
        <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
          Background → language → feel → color → logo. (Adjust anytime in Settings.)
        </div>
      </div>
    </div>
  );
}

function titleForStage(stageId: StageId) {
  switch (stageId) {
    case "orientation":
      return "Welcome";
    case "whoServe":
      return "Who you serve";
    case "heart":
      return "Founder heart";
    case "craft":
      return "How you serve";
    case "values":
      return "Your non-negotiables";
    case "vision":
      return "Your vision";
    case "brand":
      return "Your space";
    case "logo":
      return "Finishing touches";
    case "ready":
      return "";
    default:
      return "Welcome";
  }
}

function subtitleForStage(stageId: StageId) {
  switch (stageId) {
    case "orientation":
      return "A calm place to hold your business — not another thing to manage.";
    case "whoServe":
      return "Name it simply. We’ll make it beautiful later.";
    case "heart":
      return "The words behind your work matter.";
    case "craft":
      return "Your skill and your story belong here.";
    case "values":
      return "Boundaries are part of care.";
    case "vision":
      return "Create the highest, grandest vision possible.";
    case "brand":
      return "We’ll reflect your energy back to you.";
    case "logo":
      return "Clean and minimal.";
    case "ready":
      return "";
    default:
      return "";
  }
}

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ─────────────────────────────────────────────────────────────────────────────
// Dashboard
// ─────────────────────────────────────────────────────────────────────────────

function Dashboard({ theme, answers, aiAvailable }: { theme: any; answers: Answers; aiAvailable: boolean }) {
  const name = answers.businessName?.trim() || "Your Business";
  const audience = answers.audienceLabel?.trim() || "clients";

  const suggestedPack = useMemo(() => {
    // Auto-suggest logic (v1): simple heuristics.
    const ind = (answers.industry || "").toLowerCase();

    if (ind.includes("wedding") || ind.includes("event")) {
      return { title: "Client Journey Pack", desc: "A calm, professional flow from inquiry → delivery." };
    }
    if (ind.includes("coach") || ind.includes("consult")) {
      return { title: "Offer & Onboarding Pack", desc: "Clarify your offer, then make onboarding effortless." };
    }
    const hrs = parseInt(answers.oneYearHours || "", 10);
    if (!Number.isNaN(hrs) && hrs <= 15) {
      return { title: "Capacity Pack", desc: "Protect your time with boundaries and automation-ready defaults." };
    }
    return { title: "Client Deliverables Pack", desc: "Set up your client-facing assets once, reuse forever." };
  }, [answers.industry, answers.oneYearHours]);

  return (
    <div className="mt-6 space-y-6">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
            Welcome back, {name}
          </div>
          <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
            Everything important lives here.
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button kind="primary" theme={theme} onClick={() => alert("Start today’s build (demo)")}>
              Start today’s build
            </Button>
            <Button kind="ghost" theme={theme} onClick={() => alert("Brainstorm (demo)")}>
              Brainstorm
            </Button>
          </div>
          <div className="mt-3 text-xs" style={{ color: "var(--bs-subtext)" }}>
            Draft-first. You stay in control.
          </div>
        </Card>

        <HealthCard />

        <Card>
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
                Ask Backstage
              </div>
              <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
                One question. One calm next step.
              </div>
            </div>
            <Pill>{aiAvailable ? "AI" : "Logic"}</Pill>
          </div>
          <div className="mt-4 flex gap-2">
            <input
              className="w-full rounded-2xl border px-3 py-2 text-sm outline-none"
              style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)", color: "var(--bs-text)" }}
              placeholder="What should I focus on next?"
            />
            <Button kind="primary" theme={theme} onClick={() => alert("Ask (demo)")}>
              Ask
            </Button>
          </div>
          <div className="mt-2 text-xs" style={{ color: "var(--bs-subtext)" }}>
            Suggestions only. Nothing happens without approval.
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
              Next build
            </div>
            <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
              One clear step — no overwhelm.
            </div>
          </div>
          <Pill>Auto-suggested</Pill>
        </div>

        <div className="mt-4 rounded-3xl border p-4" style={{ borderColor: "var(--bs-border)", background: "var(--bs-surface)" }}>
          <div className="text-base font-semibold" style={{ color: "var(--bs-text)" }}>
            {suggestedPack.title}
          </div>
          <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
            {suggestedPack.desc}
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button kind="primary" theme={theme} onClick={() => alert("Start pack (demo)")}>
              Start this build
            </Button>
            <Button kind="ghost" theme={theme} onClick={() => alert("Choose another (demo)")}>
              Choose something else
            </Button>
          </div>
          <div className="mt-3 text-xs" style={{ color: "var(--bs-subtext)" }}>
            You can pause or change this anytime.
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
              Your Business Vault
            </div>
            <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
              Your digital architecture — clearly held.
            </div>
          </div>
          <Pill>Quick access</Pill>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-5">
          {VAULT_TILES.map((t) => (
            <button
              key={t.id}
              className="rounded-3xl border p-4 text-left shadow-sm transition"
              style={{ borderColor: "var(--bs-border)", background: mixHex(theme.bg, theme.surface, 0.35) }}
              onClick={() => alert(`Open ${t.title} (demo)`)}
            >
              <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
                {t.title}
              </div>
              <div className="mt-1 text-xs" style={{ color: "var(--bs-subtext)" }}>
                {t.subtitle}
              </div>
              <div className="mt-4 text-xs" style={{ color: "var(--bs-subtext)" }}>
                Templates, files, drafts, and notes
              </div>
              <div className="mt-3 text-xs font-semibold" style={{ color: "var(--bs-text)" }}>
                Open →
              </div>
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
              Work with Backstage (optional)
            </div>
            <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
              Support is here if you want it — no pressure.
            </div>
          </div>
          <Pill>Optional</Pill>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
          <OfferCard title="Ultimate Business Reset" subtitle="Self-paced clarity" note="A guided reset to bring everything into one clear place." />
          <OfferCard title="Strategy Call" subtitle="60 minutes" note="A calm plan for your next 90 days." />
          <OfferCard title="Backstage Method (DFY)" subtitle="Done-for-you" note={`We build your digital architecture so you can serve ${audience} with ease.`} />
        </div>
      </Card>
    </div>
  );
}

function HealthCard() {
  const [open, setOpen] = useState(false);

  const details: Record<HealthDomainId, { title: string; state: string; note: string }> = {
    delivery: { title: "Delivery", state: "Established", note: "Clients feel held." },
    brand: { title: "Brand", state: "In progress", note: "Your visuals are taking shape." },
    systems: { title: "Systems", state: "In progress", note: "We’re reducing repeated decisions." },
    marketing: { title: "Marketing", state: "Not started", note: "We’ll build this calmly." },
    capacity: { title: "Capacity", state: "Supported", note: "Your time is protected." },
  };

  return (
    <Card>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
            Business health
          </div>
          <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
            A snapshot — not a score.
          </div>
        </div>
        <Pill>Steady</Pill>
      </div>

      <button onClick={() => setOpen((v) => !v)} className="mt-4 w-full rounded-3xl border p-3 text-left" style={{ borderColor: "var(--bs-border)", background: "var(--bs-surface)" }} aria-expanded={open}>
        <div className="flex items-center gap-3">
          <Donut />
          <div className="flex-1">
            <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
              Tap to view details
            </div>
            <div className="mt-1 text-xs" style={{ color: "var(--bs-subtext)" }}>
              Clean icons first. Meaning on demand.
            </div>
          </div>
          <div className="text-xs font-semibold" style={{ color: "var(--bs-text)" }}>
            {open ? "Hide" : "View"}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {HEALTH_DOMAINS.map((d) => (
              <div key={d.id} className="grid h-10 w-10 place-items-center rounded-2xl border" style={{ borderColor: "var(--bs-border)", background: "var(--bs-chip)" }} aria-label={d.id} title={details[d.id as HealthDomainId].title}>
                <HealthIcon kind={d.icon} />
              </div>
            ))}
          </div>
        </div>

        {open ? (
          <div className="mt-4 space-y-2">
            {Object.entries(details).map(([k, v]) => (
              <div key={k} className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="grid h-8 w-8 place-items-center rounded-2xl border" style={{ borderColor: "var(--bs-border)", background: "var(--bs-chip)" }}>
                    <HealthIcon kind={HEALTH_DOMAINS.find((x) => x.id === k)?.icon || "ring"} small />
                  </div>
                  <div>
                    <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
                      {v.title}
                    </div>
                    <div className="text-xs" style={{ color: "var(--bs-subtext)" }}>
                      {v.note}
                    </div>
                  </div>
                </div>
                <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
                  {v.state}
                </div>
              </div>
            ))}
          </div>
        ) : null}
      </button>
    </Card>
  );
}

function OfferCard({ title, subtitle, note }: { title: string; subtitle: string; note: string }) {
  return (
    <div className="rounded-3xl border p-4" style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)" }}>
      <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
        {title}
      </div>
      <div className="mt-1 text-xs" style={{ color: "var(--bs-subtext)" }}>
        {subtitle}
      </div>
      <div className="mt-3 text-sm" style={{ color: "var(--bs-subtext)" }}>
        {note}
      </div>
      <div className="mt-4">
        <button className="rounded-2xl border px-3 py-2 text-sm font-semibold" style={{ borderColor: "var(--bs-border)", background: "var(--bs-chip)", color: "var(--bs-text)" }} onClick={() => alert(`Open ${title} (demo)`)}>
          Learn more
        </button>
      </div>
    </div>
  );
}

function Donut() {
  return (
    <svg width="110" height="110" viewBox="0 0 42 42" aria-label="Business health donut">
      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="var(--bs-border)" strokeWidth="7" />
      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="var(--bs-accent)" strokeWidth="7" strokeDasharray="72 28" strokeDashoffset="0" transform="rotate(-90 21 21)" strokeLinecap="round" opacity="0.85" />
    </svg>
  );
}

function HealthIcon({ kind, small }: { kind: string; small?: boolean }) {
  const s = small ? 14 : 16;
  const common = { width: s, height: s, fill: "none", stroke: "var(--bs-text)", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (kind) {
    case "spark":
      return (
        <svg {...common} viewBox="0 0 24 24">
          <path d="M12 2l1.5 6L20 12l-6.5 4L12 22l-1.5-6L4 12l6.5-4L12 2z" opacity="0.85" />
        </svg>
      );
    case "grid":
      return (
        <svg {...common} viewBox="0 0 24 24">
          <path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" />
        </svg>
      );
    case "wave":
      return (
        <svg {...common} viewBox="0 0 24 24">
          <path d="M3 12c2.5-3 5.5-3 8 0s5.5 3 10 0" />
          <path d="M3 17c2.5-3 5.5-3 8 0s5.5 3 10 0" opacity="0.6" />
        </svg>
      );
    case "leaf":
      return (
        <svg {...common} viewBox="0 0 24 24">
          <path d="M20 4c-8 0-14 6-14 14 8 0 14-6 14-14z" />
          <path d="M6 18c3-6 7-9 14-14" opacity="0.6" />
        </svg>
      );
    case "ring":
    default:
      return (
        <svg {...common} viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="7" />
          <path d="M12 5v2" opacity="0.6" />
        </svg>
      );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Settings
// ─────────────────────────────────────────────────────────────────────────────

function Settings({
  theme,
  answers,
  setAnswers,
  aiAvailable,
  setAiAvailable,
  onboardingCompleted,
  onRetake,
  onClose,
}: {
  theme: any;
  answers: Answers;
  setAnswers: React.Dispatch<React.SetStateAction<Answers>>;
  aiAvailable: boolean;
  setAiAvailable: (v: boolean) => void;
  onboardingCompleted: boolean;
  onRetake: () => void;
  onClose: () => void;
}) {
  const name = answers.businessName?.trim() || "Backstage";

  return (
    <div className="mt-6 space-y-4">
      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-semibold" style={{ color: "var(--bs-text)" }}>
              Settings
            </div>
            <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
              Adjust your space intentionally.
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Pill>{name}</Pill>
            <Button kind="ghost" theme={theme} onClick={onClose}>
              Close
            </Button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Business name</Label>
            <TextInput value={answers.businessName} onChange={(v) => setAnswers((p) => ({ ...p, businessName: v }))} placeholder="Business name" />
          </div>
          <div className="space-y-2">
            <Label>Industry</Label>
            <Select value={answers.industry} onChange={(v) => setAnswers((p) => ({ ...p, industry: v }))} options={INDUSTRIES} placeholder="Choose one" />
          </div>
          <div className="space-y-2">
            <Label>Audience label</Label>
            <TextInput value={answers.audienceLabel} onChange={(v) => setAnswers((p) => ({ ...p, audienceLabel: v }))} placeholder="clients" />
          </div>
          <div className="space-y-2">
            <Label>AI availability (demo)</Label>
            <div className="flex items-center gap-2">
              <Button kind={aiAvailable ? "primary" : "ghost"} theme={theme} onClick={() => setAiAvailable(true)}>
                On
              </Button>
              <Button kind={!aiAvailable ? "primary" : "ghost"} theme={theme} onClick={() => setAiAvailable(false)}>
                Off
              </Button>
            </div>
            <Hint>Backstage OS works without AI. AI only enhances when present.</Hint>
          </div>
        </div>

        <div className="mt-6 rounded-3xl border p-4" style={{ borderColor: "var(--bs-border)", background: "var(--bs-surface)" }}>
          <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
            Setup
          </div>
          <div className="mt-1 text-sm" style={{ color: "var(--bs-subtext)" }}>
            Onboarding is a one-time flow. Re-take here if you want to refresh your space.
          </div>
          <div className="mt-3">
            <Button kind="primary" theme={theme} onClick={onRetake} disabled={!onboardingCompleted && !answers.businessName}>
              Re-take onboarding
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <div className="text-sm font-semibold" style={{ color: "var(--bs-text)" }}>
          Developer notes (demo)
        </div>
        <div className="mt-2 text-sm" style={{ color: "var(--bs-subtext)" }}>
          Stored as:{" "}
          <span className="font-semibold" style={{ color: "var(--bs-text)" }}>
            {LS_KEY}
          </span>{" "}
          in localStorage.
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Confetti (gentle)
// ─────────────────────────────────────────────────────────────────────────────

function ConfettiBurst() {
  const pieces = useMemo(() => {
    const out: Array<{ left: number; delay: number; dur: number; size: number; o: number }> = [];
    for (let i = 0; i < 28; i++) {
      out.push({
        left: Math.random() * 100,
        delay: Math.random() * 0.25,
        dur: 1.6 + Math.random() * 0.9,
        size: 6 + Math.random() * 8,
        o: 0.8,
      });
    }
    return out;
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      <style>{`
        @keyframes bs-fall {
          0% { transform: translateY(-12px) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          100% { transform: translateY(110vh) rotate(540deg); opacity: 0; }
        }
      `}</style>
      {pieces.map((p, idx) => (
        <div
          key={idx}
          style={{
            position: "absolute",
            top: -20,
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.6,
            borderRadius: 999,
            background: "var(--bs-accent)",
            opacity: p.o,
            animation: `bs-fall ${p.dur}s ease-in ${p.delay}s 1 both`,
          }}
        />
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Reusable UI bits
// ─────────────────────────────────────────────────────────────────────────────

function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-3xl border p-5 shadow-sm" style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)" }}>
      {children}
    </div>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ borderColor: "var(--bs-border)", background: "var(--bs-chip)", color: "var(--bs-text)" }}>
      {children}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-xs font-semibold" style={{ color: "var(--bs-subtext)" }}>
      {children}
    </div>
  );
}

function Hint({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-xs" style={{ color: "var(--bs-subtext)" }}>
      {children}
    </div>
  );
}

function TextInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border px-3 py-2 text-sm outline-none"
      style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)", color: "var(--bs-text)" }}
    />
  );
}

function TextArea({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={4}
      className="w-full rounded-2xl border px-3 py-2 text-sm outline-none"
      style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)", color: "var(--bs-text)", resize: "vertical" }}
    />
  );
}

function Select({ value, onChange, options, placeholder }: { value: string; onChange: (v: string) => void; options: string[]; placeholder: string }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-2xl border px-3 py-2 text-sm outline-none" style={{ background: "var(--bs-surface)", borderColor: "var(--bs-border)", color: "var(--bs-text)" }}>
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

function Chip({ children, active, theme, onClick }: { children: React.ReactNode; active: boolean; theme: any; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="rounded-full border px-3 py-1 text-sm font-semibold transition"
      style={{
        borderColor: "var(--bs-border)",
        background: active ? "var(--bs-accent)" : "var(--bs-chip)",
        color: active ? theme.accentText : "var(--bs-text)",
      }}
    >
      {children}
    </button>
  );
}

function PickCard({ title, selected, onClick }: { title: string; selected: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className="rounded-3xl border p-4 text-left transition" style={{ borderColor: "var(--bs-border)", background: selected ? "var(--bs-accent)" : "var(--bs-chip)", color: "var(--bs-text)" }}>
      <div className="text-sm font-semibold">{title}</div>
      <div className="mt-1 text-xs" style={{ color: "var(--bs-subtext)" }}>
        {selected ? "Selected" : " "}
      </div>
    </button>
  );
}

function Button({ theme, kind, onClick, children, disabled }: { theme: any; kind: "primary" | "ghost"; onClick: () => void; children: React.ReactNode; disabled?: boolean }) {
  const base = "rounded-2xl px-4 py-2 text-sm font-semibold shadow-sm transition disabled:opacity-50 disabled:cursor-not-allowed";
  if (kind === "primary") {
    return (
      <button onClick={onClick} disabled={disabled} className={base} style={{ background: "var(--bs-primaryBg)", color: "var(--bs-primaryText)" }}>
        {children}
      </button>
    );
  }
  return (
    <button onClick={onClick} disabled={disabled} className={cx(base, "border")} style={{ borderColor: "var(--bs-border)", background: "var(--bs-surface)", color: "var(--bs-text)" }}>
      {children}
    </button>
  );
}
